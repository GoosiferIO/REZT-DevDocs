Return to [start here](app://obsidian.md/start%20here.md) / [Mapped Code](app://obsidian.md/General/Mapped%20Code.md)

# `ZTResearchMgr

Not much is known about how this class works yet, but given its namesake, it's likely to do with research. We know its name because we have been able to map symbols with their pointers using a function that calls [[BFRegistry]].

The class constructor is at `0x00635100`.

# Table of Contents

[[#Structure]]
   [[#Member Functions]]

# Structure

## Member Functions

This is the only known function part of this structure at this time.

|Member|Location|Ret Type|Member Type|Description|
|---|---|---|---|---|
||`*(00639010) + 4`|unknown|virtual function|Possibly a pointer to virtual function. Not much information given by Ghidra.|